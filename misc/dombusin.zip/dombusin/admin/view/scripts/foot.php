		<tr>
			<td height=1% style="background-color: #000000; border-top: 1px solid #999999; color: #666666; font-size: 11px; font-weight: bold; text-align: right" colspan=2>
				<a href="http://asweb.com.ua" style="color: #666666; font-size: 14px; font-weight: bold;"><img src="<?=$this->path?>/img/suleymanov.jpg" alt="александр сулейманов" align="absmiddle"></a>
			</td>
		</tr>
	</table>
</body>
</html>