<?php
	set_time_limit(0);
	$Session = new Model_Session();
	
	$sessions = $Session->getall();
	foreach($sessions as $k => $v){
		echo $v->prod."_".$v->prodvar."_".$v->user."<br>";
		$id = md5($v->prod."_".$v->prodvar."_".$v->user);
		$Session->update(array("cart_id" => $id), array("where" => "id = ".$v->id));
	}