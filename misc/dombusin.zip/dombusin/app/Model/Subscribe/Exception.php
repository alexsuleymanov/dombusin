<?
	class Model_Subscribe_Exception extends Exception{
    }
