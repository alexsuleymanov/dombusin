<?
	class Model_Distrib_Exception extends Exception{
    }
