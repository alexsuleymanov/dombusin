<?
	Zend_Session::start();

	if(!isset($_SESSION['compare'])) $_SESSION['compare'] = array();
