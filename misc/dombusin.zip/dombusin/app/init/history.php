<?
	$visited_prods = new AS_History('prod', 10);
